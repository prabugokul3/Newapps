<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Note;

class User extends Model
{
    protected $fillable = [
        'id',
        'name',
        'email',
        'password',

    ];
    public function notes(){
        return $this->hasMany(User::class,'user_id','id');

    }
}
