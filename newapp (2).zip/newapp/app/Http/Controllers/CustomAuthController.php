<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Note;
use Hash;
use Session;

class CustomAuthController extends Controller
{
    public function login(){
        return view('login');
    }

    public function registration(){
        return view('registration');
    }
    public function registerUser(Request $request){

       $request->validate([
        'name'=>'required',
        'email'=>'required|email|unique:users',
        'password'=>'required|min:5|max:12'

       ]);
       $user = new User();
       $user->name = $request->name;
       $user->email = $request->email;
       $user->password = Hash::make($request->password);
       $request = $user->save();
       return redirect('home');
       if($request){
        return back()->with('success','you have registered successfully');
       }else{
        return back()->with('fail','something wrong');
       }


    }
    public function loginUser(Request $request){
        $request->validate([

            'email'=>'required|email',
            'password'=>'required|min:5|max:12'

           ]);
           $user = User::where('email', '=' , $request->email)->first();
           if($user) {
            if (Hash::check($request->password, $user->password)) {
                $request->session()->put('loginId',$user->id);
                return redirect('dashboard');

            } else {
                return back()->with('fail','password not matches.');
            }
           } else {

            return back()->with('fail','this email is not registered.');
           }

    }
    public function dashboard(){
        $data = array();
        if (Session::has('loginId')) {
            $data = User::where('id', '=' , Session::get('loginId'))->first();
        }
        return view('dashboard',compact('data'));

    }
    public function logout(){
        if (Session::has('loginId')) {
            Session::pull('loginId');
            return redirect('login');
        }
    }
    public function homeNote(Request $request){

        $request->validate([
         'phonenumber'=>'required',
         'address'=>'required',



        ]);
        $note = new Note();
        $note->phonenumber = $request->phonenumber;
        $note->address = $request->address;
        $user_id = Session::get('loginId');
        $note['users'] = User::GetUserData($user_id)->first();
        $request = $note->save();

        $note = User::where('id', '=' , $request->id)->first();
           if($note) {
            if (Hash::check($request->password, $user->password)) {
                $request->session()->put('loginId',$user->id);
                return redirect('dashboard');

            } else {
                return back()->with('fail','password not matches.');
            }
           } else {

            return back()->with('fail','this email is not registered.');
           }


}
}
